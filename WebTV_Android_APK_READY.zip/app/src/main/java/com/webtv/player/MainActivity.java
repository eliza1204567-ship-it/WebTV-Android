package com.webtv.player;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText urlInput;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(12, 8, 12, 8);
        bar.setBackgroundColor(Color.rgb(20, 20, 20));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("https://www.youtube.com/watch?v=...");
        urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.GRAY);
        urlInput.setBackgroundColor(Color.rgb(40, 40, 40));

        Button open = new Button(this);
        open.setText("ABRIR");
        open.setOnClickListener(v -> openUrl(urlInput.getText().toString()));

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setText("WebTV listo");
        status.setPadding(12, 0, 12, 0);

        bar.addView(urlInput, new LinearLayout.LayoutParams(0, 60, 1));
        bar.addView(open, new LinearLayout.LayoutParams(130, 60));
        bar.addView(status, new LinearLayout.LayoutParams(180, 60));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        root.addView(bar);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        String incoming = getIntent() != null ? getIntent().getDataString() : null;
        if (incoming != null && !incoming.isEmpty()) {
            urlInput.setText(incoming);
            openUrl(incoming);
        }
    }

    private boolean isYouTube(Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        String h = uri.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        return h.equals("youtube.com") || h.equals("www.youtube.com")
                || h.equals("m.youtube.com") || h.equals("youtu.be");
    }

    private void openUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        Uri uri;
        try {
            uri = Uri.parse(value);
        } catch (Exception e) {
            status.setText("URL inválida");
            return;
        }

        if (!isYouTube(uri)) {
            status.setText("Usa un enlace HTTPS de YouTube");
            return;
        }

        status.setText("Cargando…");
        urlInput.setText(value);
        webView.loadUrl(value);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getDataString() != null) {
            urlInput.setText(intent.getDataString());
            openUrl(intent.getDataString());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
