# WebTV Android — APK build

Este proyecto es una prueba del reproductor Android WebView para WebTV.

- Java + Android WebView nativo (sin Kotlin ni AppCompat).
- Android Gradle Plugin 9.1.1.
- Gradle 9.3.1.
- JDK 17.
- compileSdk 36.
- Reproduce páginas de YouTube dentro del WebView cuando el vídeo permite reproducción embebida.
