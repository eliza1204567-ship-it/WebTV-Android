package com.webtv.player;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;
    private EditText urlInput;
    private TextView status;

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("WebTV • Enlace de YouTube");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(android.view.Gravity.CENTER_VERTICAL);
        title.setPadding(dp(16), 0, dp(16), 0);
        title.setBackgroundColor(Color.rgb(15, 15, 15));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setPadding(dp(12), dp(10), dp(12), dp(10));
        bar.setBackgroundColor(Color.rgb(25, 25, 25));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextSize(16);
        urlInput.setHint("Pega aquí el enlace de YouTube");
        urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.LTGRAY);
        urlInput.setPadding(dp(14), 0, dp(14), 0);
        urlInput.setBackgroundColor(Color.rgb(50, 50, 50));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button open = new Button(this);
        open.setText("▶  ABRIR VIDEO");
        open.setTextSize(15);
        open.setOnClickListener(v -> openUrl(urlInput.getText().toString()));

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setText("Listo");
        status.setTextSize(14);
        status.setGravity(android.view.Gravity.CENTER_VERTICAL);
        status.setPadding(dp(12), 0, 0, 0);

        buttons.addView(open, new LinearLayout.LayoutParams(dp(180), dp(54)));
        buttons.addView(status, new LinearLayout.LayoutParams(0, dp(54), 1));

        bar.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(58)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(8);
        bar.addView(buttons, bp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        handleIntent(getIntent());
    }

    private void handleIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri data = intent.getData();
        if ("webtv".equalsIgnoreCase(data.getScheme())) {
            String target = data.getQueryParameter("url");
            if (target != null && !target.isEmpty()) {
                urlInput.setText(target);
                openUrl(target);
            } else {
                status.setText("Enlace WebTV sin URL");
            }
            return;
        }
        String incoming = data.toString();
        urlInput.setText(incoming);
        openUrl(incoming);
    }

    private boolean isYouTube(Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        String h = uri.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        return h.equals("youtube.com") || h.equals("www.youtube.com")
                || h.equals("m.youtube.com") || h.equals("youtu.be");
    }

    private void openUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        Uri uri;
        try {
            uri = Uri.parse(value);
        } catch (Exception e) {
            status.setText("URL inválida");
            return;
        }

        if (!isYouTube(uri)) {
            status.setText("Usa un enlace HTTPS de YouTube");
            return;
        }

        status.setText("Cargando…");
        urlInput.setText(value);
        webView.loadUrl(value);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
