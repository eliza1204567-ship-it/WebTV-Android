# WebTV Android Bridge V3

Reproductor Android WebView para WebTV.

Acepta enlaces normales de YouTube y enlaces de puente: `webtv://play?url=<URL_ENCODED_YOUTUBE>`.

Al abrir un enlace `webtv://`, la app extrae el parámetro `url` y carga automáticamente el vídeo de YouTube dentro del WebView.

Nota: el Add-On de Bedrock no puede lanzar arbitrariamente una Activity Android por sí solo; esta URI sirve como puente para que Android abra la app cuando el enlace es abierto por el usuario.
