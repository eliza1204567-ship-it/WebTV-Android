plugins {
    id("com.android.application")
}

android {
    namespace = "com.webtv.player"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.webtv.player"
        minSdk = 24
        targetSdk = 36
        versionCode = 3
        versionName = "0.3"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
