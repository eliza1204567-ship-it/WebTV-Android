# WebTV Android Bridge V4

WebTV Player para Android.

Funciones:
- Reproduce enlaces HTTPS de YouTube.
- Recibe el esquema personalizado `webtv://play?url=<URL_ENCODED_YOUTUBE>`.
- Recibe enlaces de YouTube mediante Android Share (`ACTION_SEND`).
- Mantiene reproducción multimedia en WebView.

Prueba recomendada:
1. Desde otra app, comparte un enlace de YouTube.
2. Selecciona WebTV Player.
3. WebTV debe cargar automáticamente el vídeo.

Importante:
Un Add-On de Minecraft Bedrock no puede, por sí solo, ejecutar una Activity Android arbitraria. El esquema `webtv://` permite que Android abra la app cuando otro componente del sistema abre ese URI.
