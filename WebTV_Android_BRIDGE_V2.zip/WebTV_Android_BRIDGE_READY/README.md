# WebTV Player Bridge 0.2

Android companion for the Minecraft WebTV project.

Features:
- Plays YouTube links in the built-in WebView with audio.
- Accepts normal HTTPS YouTube links.
- Accepts `webtv://play?url=<encoded-youtube-url>` deep links.
- When opened/resumed, it checks the Android clipboard and automatically loads a YouTube URL if one is present.

Important limitation: Minecraft Bedrock Add-Ons do not expose an official API to launch arbitrary Android applications/intents. Therefore the Add-On cannot directly launch this APK from a script. The clipboard/deep-link support provides the Android-side bridge without requiring a PC.
