# WebTV Android — WebView Player

Prueba 1 del componente Android para el proyecto WebTV.

## Qué hace

- Abre una URL de YouTube dentro de un WebView.
- Mantiene el video dentro de la app.
- JavaScript y almacenamiento web están habilitados.
- Se habilita reproducción multimedia sin requerir gesto para cada reproducción.
- Soporta enlaces `youtube.com` y `youtu.be`.
- Puede recibir una URL mediante un Android Intent.
- Está preparado para pantalla horizontal y mantiene la pantalla encendida.

Android documenta WebView como el componente para incrustar contenido web dentro de una app. El proyecto usa AndroidX WebKit 1.16.0.

## Importante

Esta es la **prueba del reproductor Android**, no todavía la integración dentro del cliente de Minecraft Bedrock.

El siguiente puente sería:

Minecraft Bedrock → URL guardada → componente Android → WebView → YouTube + audio

Un Add-On Bedrock por sí solo no puede crear este WebView sobre su propia superficie 3D.

## Compilar

Abrir la carpeta en Android Studio y sincronizar Gradle.

Requisitos usados:
- Android Gradle Plugin 9.1.1
- Gradle 9.3.1
- JDK 17
- compileSdk 36
- minSdk 24

Luego:
Build > Build APK(s)

## Prueba

Pega:
https://www.youtube.com/watch?v=dQw4w9WgXcQ

Pulsa ABRIR.

Nota: algunos videos pueden bloquear la reproducción embebida por restricciones del propio video/YouTube.
