package com.webtv.player

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.app.Activity

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(20, 20, 20))
        }

        urlInput = EditText(this).apply {
            hint = "https://www.youtube.com/watch?v=..."
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(40, 40, 40))
        }

        val open = Button(this).apply {
            text = "ABRIR"
            setOnClickListener { openUrl(urlInput.text.toString()) }
        }

        status = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            text = "WebTV listo"
            setPadding(12, 0, 12, 0)
        }

        bar.addView(urlInput, LinearLayout.LayoutParams(0, 60, 1f))
        bar.addView(open, LinearLayout.LayoutParams(130, 60))
        bar.addView(status, LinearLayout.LayoutParams(160, 60))

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadsImagesAutomatically = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.setSupportMultipleWindows(true)
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    return false
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean = false
            }

            setBackgroundColor(Color.BLACK)
        }

        root.addView(bar)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val incoming = intent?.dataString
        if (!incoming.isNullOrBlank()) {
            urlInput.setText(incoming)
            openUrl(incoming)
        }
    }

    private fun openUrl(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) {
            status.text = "Escribe una URL"
            return
        }

        val uri = try { Uri.parse(value) } catch (_: Exception) { null }
        if (uri == null || uri.scheme != "https") {
            status.text = "Solo HTTPS"
            return
        }

        if (!isYouTube(uri)) {
            status.text = "URL no reconocida"
            return
        }

        status.text = "Cargando YouTube…"
        urlInput.setText(value)
        webView.loadUrl(value)
    }

    private fun isYouTube(uri: Uri): Boolean {
        val host = (uri.host ?: "").lowercase()
        return host == "youtube.com" ||
               host == "www.youtube.com" ||
               host == "m.youtube.com" ||
               host == "youtu.be"
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val url = intent?.dataString
        if (!url.isNullOrBlank()) {
            urlInput.setText(url)
            openUrl(url)
        }
    }

    @Deprecated("Deprecated in Android API; retained for simple back navigation.")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
